import { SearchArrTwoPipe } from './search-arr-two.pipe';

describe('SearchArrTwoPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchArrTwoPipe();
    expect(pipe).toBeTruthy();
  });
});
