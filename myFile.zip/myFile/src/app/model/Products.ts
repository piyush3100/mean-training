export class Products {
    productId: number;
    productName: string;
    imageUrl: string;
    description: string;
    premium: number;
    quantity: number;
    insurerCover: string;
    constructor(productId: number, productName: string, imageUrl: string, description: string, premium: number, quantity: number, insurerCover: string) {
        this.productId = productId;
        this.productName = productName;
        this.imageUrl = imageUrl;
        this.description = description;
        this.premium = premium;
        this.quantity = quantity;
        this.insurerCover= insurerCover;
    }
}