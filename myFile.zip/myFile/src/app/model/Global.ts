export class Global {
    Phone: string;
    Email: string;
    Privacy_policy: string;
    
    constructor(phone: string, email: string, privacy_policy: string) {
        this.Phone = phone;
        this.Email = email;
        this.Privacy_policy = privacy_policy;
 
    }
};
