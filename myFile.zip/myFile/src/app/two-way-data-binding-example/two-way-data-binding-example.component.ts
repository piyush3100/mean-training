import { Component } from '@angular/core';

@Component({
  selector: 'app-two-way-data-binding-example',
  standalone: false,
  templateUrl: './two-way-data-binding-example.component.html',
  styleUrl: './two-way-data-binding-example.component.css'
})
export class TwoWayDataBindingExampleComponent {

}
