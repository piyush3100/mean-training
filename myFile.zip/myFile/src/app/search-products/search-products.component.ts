import { Component } from '@angular/core';
import { Products } from '../model/Products';

@Component({
  selector: 'app-search-products',
  standalone: false,
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent {
  productsArr: Products[];
  searchText: string;
  fieldName: string;
  fieldsNameArr: string[];
  constructor() {
    this.fieldName= "";
    this.productsArr = [
      new Products(101, "Life Insurance", "life-insurance.png", "Life Insurance 256gb with colour", 18449, 1, "1 Cr"),
      new Products(102, "Health Insurance", "healthInsurance.jpg", "Health Insurance 256gb with colour", 42528, 5, "7 Lakhs"),
      new Products(103, "Property Insurance", "property-insurance.jpg", "Property Insurance 256gb with colour", 34500, 3, "5 Lakhs"),
      new Products(104, "Car Insurance", "car-insurance.jpg", "Car Insurance 256gb with colour", 24599, 6, "3 Lakhs"),
      new Products(105, "Drone Insurance", "drone-insurance.png", "Drone Insurance 256gb with colour", 28599, 7, "4 Lakhs"),
      new Products(106, "Broker Service", "broker.jpg", "Brokerage Service 256gb with colour", 35000, 1, "1 Lakh"),
    ];
    this.searchText = "";
    this.fieldsNameArr = ["productId", "productName", "insurerCover", "premium", "quantity"];
  }
  searchEventHandler(text: string, fieldName: string) {
    this.searchText = text;
    this.fieldName = fieldName;
  }
}
