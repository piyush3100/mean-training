import { Component } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../model/Cart';

@Component({
  selector: 'app-product-display',
  standalone: false,
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent {
  productsArr: Products[];
  companyName: string;
  showAddToCart: boolean;
  selectedProduct: Products | null;

  constructor() {
    this.selectedProduct = null;
    this.companyName = "Marsh";
    this.showAddToCart = false;
    this.productsArr = [
      new Products(101, "Life Insurance", "life-insurance.png", "Life Insurance 256gb with colour", 18449, 4, "1 Cr"),
      new Products(102, "Health Insurance", "healthInsurance.jpg", "Health Insurance 256gb with colour", 42528, 5, "7 Lakhs"),
      new Products(103, "Property Insurance", "property-insurance.jpg", "Property Insurance 256gb with colour", 34500, 3, "5 Lakhs"),
      new Products(104, "Car Insurance", "car-insurance.jpg", "Car Insurance 256gb with colour", 24599, 6, "3 Lakhs"),
      new Products(105, "Drone Insurance", "drone-insurance.png", "Drone Insurance 256gb with colour", 28599, 7, "4 Lakhs"),
      new Products(106, "Broker Service", "broker.jpg", "Brokerage Service 256gb with colour", 35000, 7, "1 Lakh")
    ];
  }

  addToCart(selectedProduct: Products) {
    alert("Button clicked: " + selectedProduct.productName);
    this.showAddToCart = true;
    this.selectedProduct = selectedProduct; //this.isValidated=true;
  }
  changeCompanyname(){
    this.companyName = "Starr";
  }

  sendDataFromAddToCartToPDEventHandler(cartObj: Cart | null){ 
    if (cartObj != null) {
      // update the quantity in productsArr
      var pos = this.productsArr.findIndex(product => product.productId == cartObj.productId);
      if (pos >= 0) {
        this.productsArr[pos].quantity = this.productsArr[pos].quantity - cartObj.quantitySelected;
      }

      // unmount the child component
      this.showAddToCart = false;
      // selectedProduct -- null
      this.selectedProduct = null;
    }
  }
  sendCancelEventFromAddToCartToPDEventHandler()
  {
    this.showAddToCart = false;
    this.selectedProduct = null;
  }
}
