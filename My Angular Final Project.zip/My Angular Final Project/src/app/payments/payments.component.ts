import { Component } from '@angular/core';

@Component({
  selector: 'app-payments',
  standalone: false,
  templateUrl: './payments.component.html',
  styleUrl: './payments.component.css'
})

export class PaymentsComponent {
  activeLink: string = 'card'; // Default active link

  setActive(link: string) {
    this.activeLink = link; // Set the active link based on user selection
  }
}
