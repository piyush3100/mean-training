import { Component, EventEmitter, Input, Output, OnChanges, OnInit, SimpleChanges, OnDestroy } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../model/Cart';
import { CartManagementService } from '../cart-management.service';

@Component({
  selector: 'app-add-to-cart',
  standalone: false,
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit, OnChanges {
  cartObj: Cart | null;
  quantitySelected: number;
  totalPremium: number; // New property to hold the total premium

  @Input() companyName: string; 
  @Input("selProduct") product: Products | null;
  
  @Output() sendDataFromAddToCartToPD: EventEmitter<Cart | null>;
  @Output() sendCancelEventFromAddToCartToPD: EventEmitter<Cart | void>;
  
  constructor(private cartManagementService: CartManagementService) {
    console.log("Constructor of Add To cart called")
    this.companyName = "Marsh";
    this.product = null;
    this.quantitySelected = 1;
    this.totalPremium = 0; // Initialize total premium
    this.sendDataFromAddToCartToPD = new EventEmitter<Cart | null>();
    this.sendCancelEventFromAddToCartToPD = new EventEmitter<Cart | void>();
    this.cartObj = null;
  }

  ngOnDestroy(): void {
    if (this.cartObj) {
      alert("Items added to the cart: " + this.product?.productId);
    }
    else {
      alert("Apologies, items cancelled: " +  this.product?.productId);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("ngOnChange in Add to Cart called");
    console.log("Changes", changes);
    if(changes['product'] && changes['product'].previousValue && changes['product'].currentValue.productId !== changes['product'].previousValue.productId){
      this.quantitySelected = 1;
    }
    console.log("Selected Product", this.product);
    this.calculateTotalPremium(); // Recalculate total premium when product changes
  }

  ngOnInit() {
    console.log("ngOnInit of Add To cart called");
    console.log("Selected Product", this.product);
    this.calculateTotalPremium(); // Calculate total premium on initialization
  }

  modifyQuantity(op: string) {
    if (op == "dec") {
      if (this.quantitySelected > 1) {
        this.quantitySelected--;
      }
    } else {
      if (this.product && (this.quantitySelected < this.product.quantity)) {
        this.quantitySelected++;
        console.log("Selected Quantity: " + this.quantitySelected);
      }
    }
    this.calculateTotalPremium(); // Recalculate total premium when quantity changes
  }

  calculateTotalPremium() {
    if (this.product) {
      this.totalPremium = this.quantitySelected * this.product.premium; // Calculate total premium
    } else {
      this.totalPremium = 0; // Reset if no product
    }
  }

  confirmEventHandler() {
    if (this.product) {
        const totalPremium = this.product.premium * this.quantitySelected; // Calculate total premium for this product
        this.cartObj = new Cart(
            this.product.productId,
            this.product.productName,
            this.product.imageUrl,
            this.product.description,
            this.product.premium,
            this.product.quantity,
            this.quantitySelected,
            this.product.insurerCover,
            totalPremium // Add totalPremium to the cart object
        );

        // Emit the cart object and add it to the cart management service
        this.sendDataFromAddToCartToPD.emit(this.cartObj);
        this.cartManagementService.addCartItem(this.cartObj);
    }
  }


  cancelEventHandler() {
    this.sendCancelEventFromAddToCartToPD.emit();
  }
}
