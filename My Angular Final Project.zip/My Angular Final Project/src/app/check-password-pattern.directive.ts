import { Directive } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { validatePasswordPattern } from './ValidatorFunctions/validateEmailPattern';

@Directive({
  selector: '[appCheckPasswordPattern]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: CheckPasswordPatternDirective, multi: true }
  ],
  standalone: false
})
export class CheckPasswordPatternDirective implements Validator{

  constructor() { }
  validate(control: AbstractControl): ValidationErrors | null {
    return validatePasswordPattern()(control);
  }

}
