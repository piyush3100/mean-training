import { Component } from '@angular/core';
//import { Cart } from '../model/Cart';
 
@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  showCart: boolean;
  // cartItems: Cart[] | null;
  constructor() {
    this.showCart = false;
    // this.cartItems = [];
  }
 
  showElement(componentName: string) {
    if (componentName == 'cart') {
      this.showCart = true;
    }
    else {
      this.showCart = false;
    }
  }
  // sendDataFromPDToCartEventHandler(cartItem:Cart | null) {
  //   console.log("sendDataFromPDToCartEventHandler() called: ", cartItem?.productId);
    
  //   if(cartItem) {
  //     this.cartItems?.push(cartItem);
  //   }
  // }
}