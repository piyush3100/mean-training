import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class AppComponent {
  title = 'myFirstProject';
  companyName: string;
  fruits: string[];
  isMember: boolean;
  ctr: number;
  empObj: any;
  bday: Date;
  imageUrl:string;
 constructor() {
  this.companyName="Marsh";
  this.fruits=["apple","guava","mangoes"];
  this.isMember= true;
  this.ctr= 123;
  this.empObj = {empId: 101, empNmae: "piyush", salary: 23424};
  this.bday =  new Date(2025, 0,21);
  this.imageUrl="thankyou.jpeg";
 }
}
