import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-wallet',
  standalone: false,
  templateUrl: './payment-by-wallet.component.html',
  styleUrl: './payment-by-wallet.component.css'
})
export class PaymentByWalletComponent {

}
