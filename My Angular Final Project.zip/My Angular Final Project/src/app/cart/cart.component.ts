import { Component, Input } from '@angular/core';
import { Cart } from '../model/Cart';
import { Router } from '@angular/router';
import { CartManagementService } from '../cart-management.service';
import { Products } from '../model/Products';

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cartArr: Cart[];
  totalCartPremium: number = 0;
  totalProducts: number = 0;

  constructor(private router: Router, cms:CartManagementService) {
    this.cartArr = cms.getAllCartItems();
    this.calculateTotal();
    this.calculateTotalProduct();
  }

  proceedToPaymentEventHandler() {
    //navigate to /payments
    this.router.navigate(['/payments']);
  }

  calculateTotal() {
    this.totalCartPremium = this.cartArr.reduce((sum, item) => sum + item.totalPremium, 0);
  }
  calculateTotalProduct(){
    this.totalProducts = this.cartArr.reduce((sum, item) => sum + item.quantitySelected, 0);
  }
}