import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-payment-by-card',
  standalone: false,
  templateUrl: './payment-by-card.component.html',
  styleUrls: ['./payment-by-card.component.css'] 
})
export class PaymentByCardComponent {
  paymentForm: FormGroup;

  constructor(private fb: FormBuilder) {
    // Initialize the form with FormBuilder
    this.paymentForm = this.fb.group({
      cardNumber: ['', [Validators.required, Validators.pattern(/^\d{4} \d{4} \d{4} \d{4}$/)]],
      expirationDate: ['', [Validators.required, Validators.pattern(/^(0[1-9]|1[0-2])\/?([0-9]{2})$/)]],
      cvv: ['', [Validators.required, Validators.pattern(/^\d{3}$/)]]
    });
  }

  onCardNumberInput(event: any) {
    const input = event.target.value.replace(/\D/g, ''); // Remove non-digit characters
    const formatted = input.replace(/(\d{4})(?=\d)/g, '$1 ').trim(); // Format as "XXXX XXXX XXXX XXXX"
    this.paymentForm.patchValue({ cardNumber: formatted.substring(0, 19) }); // Limit to 19 characters (16 digits + 3 spaces)
  }

  onExpirationDateInput(event: any) {
    const input = event.target.value.replace(/\D/g, ''); // Remove non-digit characters
    let formatted = '';

    if (input.length > 0) {
      formatted += input.substring(0, 2); // MM
    }
    if (input.length >= 2) {
      formatted += '/' + input.substring(2, 4); // Add '/' after MM
    }
    this.paymentForm.patchValue({ expirationDate: formatted }); // Update the form control
  }

  onCvvInput(event: any) {
    const input = event.target.value.replace(/\D/g, ''); // Remove non-digit characters
    this.paymentForm.patchValue({ cvv: input.substring(0, 3) }); // Limit to 3 digits
  }

  onSubmit() {
    if (this.paymentForm.valid) {
      // Show success alert
      alert('Your payment has been received. Thank you!');
      console.log('Payment submitted', this.paymentForm.value);
      // Handle the payment processing logic here
      this.paymentForm.reset(); // Optionally reset the form after submission
    } else {
      console.log('Form is invalid');
    }
  }
}
