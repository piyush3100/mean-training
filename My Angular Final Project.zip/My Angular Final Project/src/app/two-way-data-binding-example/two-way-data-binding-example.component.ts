import { Component } from '@angular/core';
import { Products } from '../model/Products';

@Component({
  selector: 'app-two-way-data-binding-example',
  standalone: false,
  templateUrl: './two-way-data-binding-example.component.html',
  styleUrls: ['./two-way-data-binding-example.component.css']
})
export class TwoWayDataBindingExampleComponent {
  countryName: string;
  personName:string | undefined;
  fieldNameArr:string[];
  fieldName:string;

  constructor(){
    this.countryName="India";
    this.personName="Piyush";
    this.fieldNameArr=["productId","productName","premium","description","quantity"];
    this.fieldName = this.fieldNameArr[1];
}

inputEventHandler(event:any){
  console.log("value type:", event.target.value);
    this.countryName = event.target.value;
 
}
}
