import { CheckPasswordPatternDirective } from './check-password-pattern.directive';

describe('CheckPasswordPatternDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckPasswordPatternDirective();
    expect(directive).toBeTruthy();
  });
});
